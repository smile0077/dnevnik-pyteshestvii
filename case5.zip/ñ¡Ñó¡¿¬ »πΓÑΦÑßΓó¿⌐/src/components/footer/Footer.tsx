import styles from './Footer.module.scss'

const Footer = () => {

    return (
        <div className={styles['footer']}>
            ArtKonX © 2024
        </div>
    )
}

export default Footer