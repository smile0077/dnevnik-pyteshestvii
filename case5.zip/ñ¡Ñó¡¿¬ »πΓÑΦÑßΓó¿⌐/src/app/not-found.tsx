import NotFoundPage from '@/components/notFound/NotFoundPage'

export default function NotFound() {
    return (
        <>
            <NotFoundPage />
        </>
    )
}